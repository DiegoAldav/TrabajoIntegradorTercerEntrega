package Enum;

public enum Resultado {
	ganador,
	perdedor,
	empate,
	desconocido;

}
